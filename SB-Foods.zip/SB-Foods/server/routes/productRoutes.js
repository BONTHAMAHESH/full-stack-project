const express = require('express');
const router = express.Router();

// Define product routes here
// Example: router.get('/', (req, res) => { res.send('Product list'); });

module.exports = router;