const express = require('express');
const router = express.Router();

const menu = [
  { id: '1', name: 'Mc Maharaj', price: 175 },
  { id: '2', name: 'French Fries', price: 134 },
  { id: '3', name: 'Cold Coffee', price: 201 },
  { id: '4', name: 'Chicken Pizza', price: 314 },
  { id: '5', name: 'Chicken Biryani', price: 299 },
  // Add more items as needed
];

// GET /api/menu
router.get('/', (req, res) => {
  res.json(menu);
});

module.exports = router;