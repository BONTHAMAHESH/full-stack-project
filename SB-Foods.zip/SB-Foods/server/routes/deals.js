const express = require('express');
const router = express.Router();

const deals = [
  { id: '1', title: '20% Off on Orders Above ₹500', code: 'SAVE20' },
  { id: '2', title: 'Free Delivery on First Order', code: 'FREESHIP' },
  // Add more deals as needed
];

router.get('/', (req, res) => {
  res.json(deals);
});

module.exports = router;