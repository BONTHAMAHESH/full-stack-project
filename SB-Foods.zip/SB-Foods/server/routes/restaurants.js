const express = require('express');
const router = express.Router();

const restaurants = [
  { id: '1', name: 'Mc donalds', location: 'Manikonda, Hyderabad' },
  { id: '2', name: 'Andhra Spice', location: 'Madhapur, Hyderabad' },
  { id: '3', name: 'Paradise Grand', location: 'Hitech City, Hyderabad'},
  { id: '4', name: 'Minerva Grand', location: 'Kondapur, Hyderabad'},
  { id: '5', name: 'Kritunga', location: 'Gachibowli, Hyderabad'},
  { id: '6', name: 'Exotica', location: 'Banjara Hills, Hyderabad'},
  // Add more restaurants as needed
];

router.get('/', (req, res) => {
  res.json(restaurants);
});

module.exports = router;