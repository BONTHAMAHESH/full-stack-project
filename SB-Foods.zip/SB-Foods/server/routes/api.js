const express = require('express');
const router = express.Router();

// Home page data
router.get('/home', (req, res) => {
  res.json({ message: 'Welcome to SB Foods Home!' });
});

// Restaurants list
router.get('/restaurants', (req, res) => {
  res.json([
    { id: 1, name: 'Mc donalds', location: 'Manikonda, Hyderabad' },
    { id: 2, name: 'Andhra Spice', location: 'Madhapur, Hyderabad' },
    { id: 3, name: 'Paradise Grand', location: 'Hitech City, Hyderabad' },
    { id: 4, name: 'Minerva Grand', location: 'Kukatpally, Hyderabad' },
    { id: 5, name: 'Pizza Hut', location: 'Banjara Hills, Hyderabad' }
  ]);
});

// Menu items (all)
router.get('/menu', (req, res) => {
  res.json([
    { id: 1, name: 'Mc Maharaj', price: 199 },
    { id: 2, name: 'French fries', price: 134 },
    // ...add all menu items here
  ]);
});

// Deals
router.get('/deals', (req, res) => {
  res.json([
    { id: 1, title: '20% off on Biryani', code: 'BIRYANI20' },
    { id: 2, title: 'Free Dessert on orders above ₹500', code: 'SWEET500' }
  ]);
});

// Support info
router.get('/support', (req, res) => {
  res.json({
    email: 'support@sbfoods.com',
    phone: '+91-12345-67890',
    faq: [
      { q: 'How to order?', a: 'Browse menu and add items to cart.' },
      { q: 'How to contact support?', a: 'Email or call us anytime.' }
    ]
  });
});

// Filters (categories, types, etc.)
router.get('/filters', (req, res) => {
  res.json({
    sortBy: ['Popularity', 'Low Price', 'High Price', 'Discount', 'Rating'],
    foodType: ['Veg', 'Non Veg', 'Beverages'],
    categories: ['Biryani', 'Curry', 'Pizza', 'Dessert']
  });
});

module.exports = router;