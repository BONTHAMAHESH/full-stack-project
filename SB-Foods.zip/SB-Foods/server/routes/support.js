const express = require('express');
const router = express.Router();

const supportInfo = {
  email: 'support@sbfoods.com',
  phone: '(555) 123-4567',
  message: 'Contact us for help or questions.'
};

router.get('/', (req, res) => {
  res.json(supportInfo);
});

module.exports = router;