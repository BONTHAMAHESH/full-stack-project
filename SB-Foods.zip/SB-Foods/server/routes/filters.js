const express = require('express');
const router = express.Router();

const filters = [
  { id: '1', name: 'Cuisine', options: ['Indian', 'Chinese', 'Italian'] },
  { id: '2', name: 'Price', options: ['< ₹200', '₹200-₹500', '> ₹500'] },
  { id: '3', name: 'Rating', options: ['4+', '3+', 'All'] },
  // Add more filters as needed
];

router.get('/', (req, res) => {
  res.json(filters);
});

module.exports = router;