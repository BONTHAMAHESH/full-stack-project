const express = require('express');
const cors = require('cors');
const mongoose = require('mongoose');
const app = express();

const restaurantsRouter = require('./routes/restaurants');
const menuRouter = require('./routes/menu');
const dealsRouter = require('./routes/deals');
const supportRouter = require('./routes/support');
const filtersRouter = require('./routes/filters');

// Correct MongoDB connection string usage
mongoose.connect(
  'mongodb+srv://Bonthmahesh678:Maheshsai2712@sb-foods.izyg0tz.mongodb.net/?retryWrites=true&w=majority',
  { useNewUrlParser: true, useUnifiedTopology: true }
)
  .then(() => console.log('MongoDB connected'))
  .catch(err => console.error('MongoDB connection error:', err));

app.use(cors());
app.use(express.json());

app.use('/api/restaurants', restaurantsRouter);
app.use('/api/menu', menuRouter);
app.use('/api/deals', dealsRouter);
app.use('/api/support', supportRouter);
app.use('/api/filters', filtersRouter);

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
