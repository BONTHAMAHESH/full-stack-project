import axios from 'axios';
import React, { useEffect, useState } from 'react';

function Restaurants() {
  const [restaurants, setRestaurants] = useState([]);
  const [loading, setLoading] = useState(true);
  const API = axios.create({ baseURL: 'http://localhost:5000/api' });

  useEffect(() => {
    fetch('http://localhost:5000/api/restaurants') // Change port if needed
      .then(res => res.json())
      .then(data => {
        setRestaurants(data);
        setLoading(false);
      });
  }, []);

  if (loading) return <div>Loading...</div>;

  return (
    <div>
      <h2>Restaurants</h2>
      <ul>
        {restaurants.map(r => (
          <li key={r.id}>{r.name} - {r.location}</li>
        ))}
      </ul>
    </div>
  );
}

export default Restaurants;