export const fetchAllUsers = () => API.get('/admin/users');
export const fetchAllOrders = () => API.get('/admin/orders');
export const fetchAllProducts = () => API.get('/admin/products');