import React, { useState } from 'react';

export default function NewProductForm() {
  const [form, setForm] = useState({
    name: '', description: '', img: '', type: '', category: '', price: 0, discount: 0
  });

  const handleChange = e => setForm({ ...form, [e.target.name]: e.target.value });

  return (
    <div className="modal" style={{ background: '#18181b', color: '#fff', margin: '2rem auto', maxWidth: 600 }}>
      <h2 style={{ color: '#fff', textAlign: 'center' }}>New Product</h2>
      <form>
        <div style={{ display: 'flex', gap: '1rem', marginBottom: '1rem' }}>
          <input name="name" placeholder="Product name" value={form.name} onChange={handleChange} />
          <input name="description" placeholder="Product Description" value={form.description} onChange={handleChange} />
        </div>
        <input name="img" placeholder="Thumbnail Img url" value={form.img} onChange={handleChange} style={{ width: '100%', marginBottom: '1rem' }} />
        <div style={{ marginBottom: '1rem' }}>
          <b>Type</b><br />
          <label><input type="radio" name="type" value="Veg" onChange={handleChange} /> Veg</label>
          <label style={{ marginLeft: 10 }}><input type="radio" name="type" value="Non Veg" onChange={handleChange} /> Non Veg</label>
          <label style={{ marginLeft: 10 }}><input type="radio" name="type" value="Beverages" onChange={handleChange} /> Beverages</label>
        </div>
        <div style={{ display: 'flex', gap: '1rem', marginBottom: '1rem' }}>
          <select name="category" value={form.category} onChange={handleChange}>
            <option>Choose Product cat</option>
            <option>Biryani</option>
            <option>Curry</option>
            <option>Pizza</option>
          </select>
          <input name="price" type="number" placeholder="Price" value={form.price} onChange={handleChange} />
          <input name="discount" type="number" placeholder="Discount (in %)" value={form.discount} onChange={handleChange} />
        </div>
        <button type="submit" className="btn-primary" style={{ width: '100%' }}>Add product</button>
      </form>
    </div>
  );
}