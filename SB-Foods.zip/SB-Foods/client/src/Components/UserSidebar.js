import React from 'react';

const UserSidebar = ({ user, orderCount, onLogout }) => (
  <div className="user-sidebar-card">
    <div><b>Username:</b> <span>{user.name}</span></div>
    <div><b>Email:</b> <span>{user.email}</span></div>
    <div><b>Orders:</b> <span>{orderCount}</span></div>
    <button className="logout-btn" onClick={onLogout}>Logout</button>
  </div>
);

export default UserSidebar;
