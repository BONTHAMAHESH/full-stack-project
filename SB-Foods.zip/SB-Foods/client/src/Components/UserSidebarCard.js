import React from 'react';
import { useAuth } from '../hooks/useAuth';

export default function UserSidebarCard() {
  const { user, logout } = useAuth();
  return (
    <div className="user-sidebar-card">
      <div><b>Username:</b> {user?.name}</div>
      <div><b>Email:</b> {user?.email}</div>
      <div><b>Orders:</b> 7</div>
      <button className="logout-btn" onClick={logout}>Logout</button>
    </div>
  );
}