import React from 'react';
import { Clock, Truck, Shield, Star } from 'lucide-react';

const LateNightSection = () => {
  const features = [
    {
      icon: <Clock size={48} />,
      title: '24/7 Delivery',
      description: 'Order anytime, day or night. We never sleep so you can satisfy your cravings whenever they strike.'
    },
    {
      icon: <Truck size={48} />,
      title: 'Fast Delivery',
      description: 'Lightning-fast delivery in 30 minutes or less. Hot, fresh food delivered right to your doorstep.'
    },
    {
      icon: <Shield size={48} />,
      title: 'Safe & Secure',
      description: 'Contactless delivery options and secure payment methods for your peace of mind.'
    },
    {
      icon: <Star size={48} />,
      title: 'Top Rated',
      description: 'Thousands of 5-star reviews from satisfied customers who love our service and quality.'
    }
  ];

  return (
    <section className="late-night-section">
      <div className="late-night-container">
        <h2 className="late-night-title">Why Choose SB Foods?</h2>
        <p className="late-night-subtitle">
          We're committed to bringing you the best food delivery experience
        </p>
        <div className="late-night-grid">
          {features.map((feature, index) => (
            <div key={index} className="late-night-card">
              <div className="late-night-icon">
                {feature.icon}
              </div>
              <h3>{feature.title}</h3>
              <p>{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default LateNightSection;