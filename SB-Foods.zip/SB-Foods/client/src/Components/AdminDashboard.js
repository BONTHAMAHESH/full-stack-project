import React from 'react';

export default function AdminDashboard() {
  return (
    <div className="category-section" style={{ background: '#374151', minHeight: '100vh' }}>
      <div className="category-title" style={{ color: '#fff' }}>Dashboard</div>
      <div className="category-grid">
        <div className="category-card" style={{ background: '#22223b', color: '#fff' }}>
          <div>All Items</div>
          <div style={{ fontSize: '2rem', margin: '1rem 0' }}>4</div>
          <button className="btn-secondary">View all</button>
        </div>
        <div className="category-card" style={{ background: '#22223b', color: '#fff' }}>
          <div>All Orders</div>
          <div style={{ fontSize: '2rem', margin: '1rem 0' }}>0</div>
          <button className="btn-secondary">View all</button>
        </div>
        <div className="category-card" style={{ background: '#22223b', color: '#fff' }}>
          <div>Add Item</div>
          <div style={{ fontSize: '1rem', margin: '1rem 0' }}>(new)</div>
          <button className="btn-secondary">Add now</button>
        </div>
      </div>
    </div>
  );
}