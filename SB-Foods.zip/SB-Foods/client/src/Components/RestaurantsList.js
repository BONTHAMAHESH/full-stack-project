import React from 'react';

const restaurants = [
  { name: 'Andhra Spice', location: 'Madhapur, Hyderabad', img: '/images/andhra-spice.jpg' },
  { name: 'Mc donalds', location: 'Manikonda, Hyderabad', img: '/images/mcdonalds.jpg' },
  { name: 'Paradise Grand', location: 'Hitech city, Hyderabad', img: '/images/paradise.jpg' },
  { name: 'Minarva Grand', location: 'Kukatpally, Hyderabad', img: '/images/minerva.jpg' },
];

export default function RestaurantsList() {
  return (
    <div className="category-section">
      <div className="category-title">All restaurants</div>
      <div className="category-grid">
        {restaurants.map(r => (
          <div className="category-card" key={r.name}>
            <img src={r.img} alt={r.name} className="category-image" />
            <div className="category-name">{r.name}</div>
            <div className="category-description">{r.location}</div>
          </div>
        ))}
      </div>
    </div>
  );
}