import React from 'react';

const categories = [
  { name: 'Breakfast', img: '/images/breakfast.jpg' },
  { name: 'Biriyani', img: '/images/biryani.jpg' },
  { name: 'Pizza', img: '/images/pizza.jpg' },
  { name: 'Noodles', img: '/images/noodles.jpg' },
  { name: 'Burger', img: '/images/burger.jpg' },
];

const popularRestaurants = [
  { name: 'Andhra Spice', location: 'Madhapur, Hyderabad', img: '/images/andhra-spice.jpg' },
  { name: 'Mc donalds', location: 'Manikonda, Hyderabad', img: '/images/mcdonalds.jpg' },
  { name: 'Paradise Grand', location: 'Hitech city, Hyderabad', img: '/images/paradise.jpg' },
  { name: 'Minarva Grand', location: 'Kukatpally, Hyderabad', img: '/images/minerva.jpg' },
];

export default function LandingPage() {
  return (
    <div>
      <section className="category-section">
        <div className="category-title">Categories</div>
        <div className="category-grid">
          {categories.map(cat => (
            <div className="category-card" key={cat.name}>
              <img src={cat.img} alt={cat.name} className="category-image" />
              <div className="category-name">{cat.name}</div>
            </div>
          ))}
        </div>
      </section>
      <section className="category-section">
        <div className="category-title">Popular Restaurants</div>
        <div className="category-grid">
          {popularRestaurants.map(r => (
            <div className="category-card" key={r.name}>
              <img src={r.img} alt={r.name} className="category-image" />
              <div className="category-name">{r.name}</div>
              <div className="category-description">{r.location}</div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}