import React, { useState } from 'react';
import { useAuth } from '../../hooks/useAuth';

const Register = ({ onClose, onSwitchToLogin }) => {
  const { login } = useAuth();
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [userType, setUserType] = useState('Customer');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    setError('');
    try {
      const res = await fetch('/api/users/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, email, password, userType }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || 'Registration failed');
        setIsLoading(false);
        return;
      }
      // Optionally, auto-login after registration:
      if (data.token && data.user) {
        login(data.user, data.token);
        onClose();
      } else {
        // If backend does not return token, prompt user to login
        onSwitchToLogin();
      }
    } catch (err) {
      setError('Network error');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="modal-backdrop">
      <div className="modal">
        <button className="modal-close" onClick={onClose}>&times;</button>
        <h2 style={{ color: '#2563eb', fontWeight: 700, fontSize: '2rem', margin: 0, textAlign: 'center' }}>Register</h2>
        <form onSubmit={handleSubmit}>
          <input
            type="text"
            placeholder="Username"
            value={name}
            onChange={e => setName(e.target.value)}
            required
          />
          <input
            type="email"
            placeholder="Email address"
            value={email}
            onChange={e => setEmail(e.target.value)}
            required
          />
          <input
            type="password"
            placeholder="Password"
            value={password}
            onChange={e => setPassword(e.target.value)}
            required
          />
          <select value={userType} onChange={e => setUserType(e.target.value)} required>
            <option value="Customer">Customer</option>
            <option value="Admin">Admin</option>
            <option value="Restaurant">Restaurant</option>
          </select>
          <button type="submit" disabled={isLoading}>{isLoading ? 'Registering...' : 'Register'}</button>
        </form>
        {error && <div style={{ color: 'red', marginTop: 8 }}>{error}</div>}
        <div className="modal-switch" style={{ marginTop: 12 }}>
          Already registered?{' '}
          <span className="modal-link" onClick={onSwitchToLogin}>Login</span>
        </div>
      </div>
    </div>
  );
};

export default Register;