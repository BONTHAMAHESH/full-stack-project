import React from 'react';import { useCart } from '../../hooks/useCart';

function CartDrawer({ open, onClose }) {
  const { cartItems } = useCart();

  if (!open) return null;

  return (
    <div className="cart-drawer">
      <button onClick={onClose}>Close</button>
      <h2>Your Cart</h2>
      {cartItems.length === 0 ? (
        <p>No items in cart.</p>
      ) : (
        <ul>
          {cartItems.map(item => (
            <li key={item.id}>{item.name} x {item.quantity}</li>
          ))}
        </ul>
      )}
    </div>
  );
}

const cartItems = [
  { name: 'Chicken Biriyani', price: 262, oldPrice: 309, img: '/images/biryani.jpg', qty: 1 },
  { name: 'Butter Chicken', price: 229, oldPrice: 249, img: '/images/butter-chicken.jpg', qty: 1 },
];

export default function CartDrawer({ onClose }) {
  return (
    <div className="cart-drawer-backdrop" onClick={onClose}>
      <div className="cart-drawer" onClick={e => e.stopPropagation()}>
        <div className="cart-drawer-header">
          <span className="cart-drawer-title">Cart</span>
          <button className="cart-drawer-close" onClick={onClose}>&times;</button>
        </div>
        <div className="cart-items-list">
          {cartItems.map(item => (
            <div className="cart-item" key={item.name}>
              <img src={item.img} alt={item.name} className="cart-item-img" />
              <div className="cart-item-info">
                <div className="cart-item-title">{item.name}</div>
                <div className="cart-item-price">₹ {item.price} <span style={{ textDecoration: 'line-through', color: '#aaa', fontSize: '1rem' }}>₹{item.oldPrice}</span></div>
                <div>Quantity: {item.qty}</div>
              </div>
              <button className="cart-item-remove">Remove</button>
            </div>
          ))}
        </div>
        <div className="cart-drawer-summary">
          <div className="cart-summary-row">
            <span>Total MRP:</span>
            <span>₹ 558</span>
          </div>
          <div className="cart-summary-row">
            <span>Discount on MRP:</span>
            <span style={{ color: '#16a34a' }}>- ₹ 66</span>
          </div>
          <div className="cart-summary-row">
            <span>Delivery Charges:</span>
            <span style={{ color: '#ef4444' }}>+ ₹ 50</span>
          </div>
          <div className="cart-summary-row total">
            <span>Final Price:</span>
            <span>₹ 542</span>
          </div>
          <button className="cart-checkout-btn">Place order</button>
        </div>
      </div>
    </div>
  );
}