import React, { useState, useRef, useEffect } from 'react';
import { Search, ShoppingCart, LogIn, User, Menu } from 'lucide-react';
import { useCart } from '../../hooks/useCart';
import { useAuth } from '../../hooks/useAuth';
import { Link } from 'react-router-dom';
import { useNavigate } from 'react-router-dom';


const Header = ({ onLoginClick, searchTerm, onSearchChange }) => {
  const navigate = useNavigate();
  const { items } = useCart();
  const { user, logout } = useAuth();
  const [showHamburger, setShowHamburger] = useState(false);
  const [showProfile, setShowProfile] = useState(false);
  const hamburgerRef = useRef();
  const profileRef = useRef();
  const handleCartClick = () => {
    navigate('/cart');
  }
  const cartCount = items.reduce((sum, item) => sum + item.quantity, 0);

  // Close hamburger menu on outside click
  useEffect(() => {
    function handleClickOutside(event) {
      if (hamburgerRef.current && !hamburgerRef.current.contains(event.target)) {
        setShowHamburger(false);
      }
      if (profileRef.current && !profileRef.current.contains(event.target)) {
        setShowProfile(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  return (
    <header className="header">
      <div className="header-container" style={{ position: 'relative' }}>
        {/* Hamburger menu for logged-in users */}
        {user && (
  <div style={{ display: 'flex', alignItems: 'center', marginRight: '1rem' }}>
    <button
      className="hamburger-btn"
      style={{
        background: 'none',
        border: 'none',
        cursor: 'pointer',
        display: 'flex',
        alignItems: 'center',
        marginLeft: 0,
        marginRight: 0,
        padding: 0
      }}
      aria-label="Open menu"
      onClick={() => setShowHamburger((v) => !v)}
    >
      <Menu size={28} />
    </button>
         {showHamburger && (
              <div
                ref={hamburgerRef}
                style={{
                  position: 'absolute',
                  top: '3.2rem',
                  left: '1rem',
                  background: '#fff',
                  boxShadow: '0 4px 24px rgba(0,0,0,0.18)',
                  borderRadius: 16,
                  minWidth: 220,
                  zIndex: 200,
                  padding: '0.5rem 0',
                  transition: 'all 0.2s',
                }}
              >
                <ul style={{ 
                  listStyle: 'none', 
                  margin: 0, 
                  padding: 0, 
                  display: 'flex', 
                  flexDirection: 'column', 
                  gap: '0.5rem' 
                }}>
                  <li>
                    <Link 
                      to="/" 
                      className="hamburger-link"
                      style={{
                        display: 'block',
                        padding: '0.75rem 1.5rem',
                        color: '#222',
                        textDecoration: 'none',
                        fontWeight: 600,
                        borderRadius: 8,
                        transition: 'background 0.15s',
                      }}
                      onMouseOver={e => e.currentTarget.style.background = '#f5e9c9'}
                      onMouseOut={e => e.currentTarget.style.background = 'transparent'}
                    >
                      Home
                    </Link>
                  </li>
                  <li>
                    <Link 
                      to="/restaurants" 
                      className="hamburger-link"
                      style={{
                        display: 'block',
                        padding: '0.75rem 1.5rem',
                        color: '#222',
                        textDecoration: 'none',
                        fontWeight: 600,
                        borderRadius: 8,
                        transition: 'background 0.15s',
                      }}
                      onMouseOver={e => e.currentTarget.style.background = '#f5e9c9'}
                      onMouseOut={e => e.currentTarget.style.background = 'transparent'}
                    >
                      Restaurants
                    </Link>
                  </li>
                  <li>
                    <Link 
                      to="/menu" 
                      className="hamburger-link"
                      style={{
                        display: 'block',
                        padding: '0.75rem 1.5rem',
                        color: '#222',
                        textDecoration: 'none',
                        fontWeight: 600,
                        borderRadius: 8,
                        transition: 'background 0.15s',
                      }}
                      onMouseOver={e => e.currentTarget.style.background = '#f5e9c9'}
                      onMouseOut={e => e.currentTarget.style.background = 'transparent'}
                    >
                      Menu
                    </Link>
                  </li>
                  <li>
                    <Link 
                      to="/deals" 
                      className="hamburger-link"
                      style={{
                        display: 'block',
                        padding: '0.75rem 1.5rem',
                        color: '#222',
                        textDecoration: 'none',
                        fontWeight: 600,
                        borderRadius: 8,
                        transition: 'background 0.15s',
                      }}
                      onMouseOver={e => e.currentTarget.style.background = '#f5e9c9'}
                      onMouseOut={e => e.currentTarget.style.background = 'transparent'}
                    >
                      Deals
                    </Link>
                  </li>
                  <li>
                    <Link 
                      to="/support" 
                      className="hamburger-link"
                      style={{
                        display: 'block',
                        padding: '0.75rem 1.5rem',
                        color: '#222',
                        textDecoration: 'none',
                        fontWeight: 600,
                        borderRadius: 8,
                        transition: 'background 0.15s',
                      }}
                      onMouseOver={e => e.currentTarget.style.background = '#f5e9c9'}
                      onMouseOut={e => e.currentTarget.style.background = 'transparent'}
                    >
                      Support
                    </Link>
                  </li>
                  <li>
                    <Link 
                      to="/filters" 
                      className="hamburger-link"
                      style={{
                        display: 'block',
                        padding: '0.75rem 1.5rem',
                        color: '#222',
                        textDecoration: 'none',
                        fontWeight: 600,
                        borderRadius: 8,
                        transition: 'background 0.15s',
                      }}
                      onMouseOver={e => e.currentTarget.style.background = '#f5e9c9'}
                      onMouseOut={e => e.currentTarget.style.background = 'transparent'}
                    >
                      Filters
                    </Link>
                  </li>
                </ul>
              </div>
            )}
  </div>
)}
        <a href="/" className="logo" style={{ marginLeft: user ? '3.5rem' : 0 }}>
          SB Foods
        </a>
        <div className="search-container">
          <Search className="search-icon" size={20} />
          <input
            type="text"
            placeholder="Search Restaurants, cuisine, etc."
            className="search-input"
            value={searchTerm}
            onChange={(e) => onSearchChange && onSearchChange(e.target.value)}
          />
        </div>
        <div
          className="nav-actions"
          style={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'flex-end',
            flex: 1,
            gap: '1rem'
          }}
        >
          {user ? (
            <>
              <div style={{ position: 'relative' }}>
                <button
                  className="profile-icon-btn"
                  onClick={() => setShowProfile((v) => !v)}
                  aria-label="User profile"
                >
                  <User size={24} />
                </button>
                {showProfile && (
                  <div
                    ref={profileRef}
                    style={{
                      position: 'absolute',
                      top: '2.2rem',
                      right: 0,
                      background: '#fff',
                      boxShadow: '0 2px 8px rgba(0,0,0,0.12)',
                      borderRadius: 8,
                      minWidth: 220,
                      zIndex: 100
                    }}
                  >
                    <div style={{ padding: '1rem', borderBottom: '1px solid #eee' }}>
                      <div><b>Username:</b> {user?.name}</div>
                      <div><b>Email:</b> {user?.email}</div>
                      <div><b>User Type:</b> {user?.userType}</div>
                    </div>
                    <button
                      style={{
                        width: '100%',
                        background: '#ef4444',
                        color: '#fff',
                        border: 'none',
                        borderRadius: '0 0 8px 8px',
                        padding: '0.75rem',
                        fontWeight: 700,
                        fontSize: '1rem',
                        cursor: 'pointer'
                      }}
                      onClick={logout}
                    >
                      Logout
                    </button>
                  </div>
                )}
              </div>
              <button className="cart-button" onClick={handleCartClick}>
                <ShoppingCart size={24} />
                {cartCount > 0 && (
                  <span className="cart-count">{cartCount}</span>
                )}
                </button>
            </>
          ) : (
            <>
              <button className="nav-button" onClick={onLoginClick}>
                <LogIn size={16} className="mr-1" />
                Login
              </button>
              <button className="cart-button" onClick={handleCartClick}>
    <ShoppingCart size={24} />
    {cartCount > 0 && (
      <span className="cart-count">{cartCount}</span>
    )}
  </button>
            </>
          )}
        </div>
      </div>
    </header>
  );
};

export default Header;