import React, { useState } from 'react';
import { useCart } from '../hooks/useCart';

// Import images
import burgerImg from './images/burger.jpg';
import friesImg from './images/fries.jpg';
import coffeeImg from './images/coffee.jpg';
import pizzaImg from './images/pizza.jpg';
import ChickenImg from './images/chickencurry.jpg';
import MuttonImg from './images/mutton.jpg';
import PesarattuImg from './images/pesarattu.jpg';
import UlavacharuImg from './images/ulavacharu.jpg';
import ChickenBiryaniImg from './images/chickenbiryani.jpg';
import PaneerBiryaniImg from './images/paneerbiryani.jpg';
import SweetImg from './images/sweet.jpg';
import ThaliImg from './images/thali.jpg';
import SouththaliImg from './images/souththali1.jpg';
import IdlivadaImg from './images/idlivada.jpg';
import MasaladosaImg from './images/masaladosa.jpg';
import CoffeeImg from './images/filtercoffee.jpg';
import Pizza1Img from './images/pizza1.jpg';
import PizzapImg from './images/pizzap.jpg';
import GarlicbreadImg from './images/garlicbread.jpg';
import CakeImg from './images/cake.jpg';

const restaurants = [
  {
    id: 1,
    name: 'Mc donalds',
    location: 'Manikonda, Hyderabad',
    menu: [
      {
        name: 'Mc Maharaj',
        desc: 'Big size burger with chicken patty',
        price: 199,
        oldPrice: 249,
        img: burgerImg
      },
      {
        name: 'French fries',
        desc: 'Long French fries made from potatoes',
        price: 134,
        oldPrice: 149,
        img: friesImg
      },
      {
        name: 'Cold Coffee',
        desc: 'Tender coffee made from special beans',
        price: 150,
        oldPrice: 199,
        img: coffeeImg
      },
      {
        name: 'Chicken Pizza',
        desc: 'Crispy pizza with tasty chicken',
        price: 200,
        oldPrice: 249,
        img: pizzaImg
      }
    ]
  },
  {
    id: 2,
    name: 'Andhra Spice',
    location: 'Madhapur, Hyderabad',
    menu: [
      {
        name: 'Andhra Chicken Curry',
        desc: 'Spicy chicken curry in Andhra style',
        price: 220,
        oldPrice: 260,
        img: ChickenImg
      },
      {
        name: 'Gongura Mutton',
        desc: 'Mutton cooked with gongura leaves',
        price: 320,
        oldPrice: 370,
        img: MuttonImg
      },
      {
        name: 'Pesarattu',
        desc: 'Green gram dosa served with chutney',
        price: 90,
        oldPrice: 110,
        img: PesarattuImg
      },
      {
        name: 'Ulava Charu',
        desc: 'Horse gram soup, Andhra delicacy',
        price: 120,
        oldPrice: 150,
        img: UlavacharuImg
      }
    ]
  },
  {
    id: 3,
    name: 'Paradise Grand',
    location: 'Hitech City, Hyderabad',
    menu: [
      {
        name: 'Chicken Biryani',
        desc: 'Famous Hyderabadi chicken biryani',
        price: 250,
        oldPrice: 299,
        img: ChickenBiryaniImg
      },
      {
        name: 'Paneer Biryani',
        desc: 'Biryani with soft paneer cubes',
        price: 210,
        oldPrice: 250,
        img: PaneerBiryaniImg
      },
      {
        name: 'Double Ka Meetha',
        desc: 'Traditional Hyderabadi dessert',
        price: 80,
        oldPrice: 100,
        img: SweetImg
      },
      {
        name: 'Veg Thali',
        desc: 'Assorted vegetarian dishes',
        price: 180,
        oldPrice: 220,
        img: ThaliImg
      }
    ]
  },
  {
    id: 4,
    name: 'Minerva Grand',
    location: 'Kukatpally, Hyderabad',
    menu: [
      {
        name: 'South Indian Thali',
        desc: 'Traditional South Indian meal',
        price: 160,
        oldPrice: 200,
        img: SouththaliImg
      },
      {
        name: 'Idli Vada',
        desc: 'Soft idlis and crispy vadas',
        price: 60,
        oldPrice: 80,
        img: IdlivadaImg
      },
      {
        name: 'Masala Dosa',
        desc: 'Crispy dosa with spicy potato filling',
        price: 90,
        oldPrice: 110,
        img: MasaladosaImg
      },
      {
        name: 'Filter Coffee',
        desc: 'Authentic South Indian filter coffee',
        price: 40,
        oldPrice: 50,
        img: CoffeeImg
      }
    ]
  },
  {
    id: 5,
    name: 'Pizza Hut',
    location: 'Banjara Hills, Hyderabad',
    menu: [
      {
        name: 'Veggie Supreme Pizza',
        desc: 'Loaded with fresh veggies',
        price: 299,
        oldPrice: 349,
        img: Pizza1Img
      },
      {
        name: 'Chicken Pepperoni Pizza',
        desc: 'Pepperoni and cheese delight',
        price: 349,
        oldPrice: 399,
        img: PizzapImg
      },
      {
        name: 'Garlic Bread',
        desc: 'Crispy garlic breadsticks',
        price: 99,
        oldPrice: 120,
        img: GarlicbreadImg
      },
      {
        name: 'Choco Lava Cake',
        desc: 'Warm chocolate cake with molten center',
        price: 89,
        oldPrice: 110,
        img: CakeImg
      },
    ]
  }
];

export default function RestaurantMenu() {
  const [showFilters] = useState(false);
  const { addToCart } = useCart();

  // Helper to generate a unique id for each menu item
  const getItemId = (restaurantId, itemName) => `${restaurantId}-${itemName.replace(/\s+/g, '-')}`;

  return (
    <div style={{ display: 'flex', flexDirection: 'column', padding: '2rem 2rem 0 2rem', gap: '2.5rem', position: 'relative' }}>
      {/* Filters Sidebar (drawer style for mobile/desktop) */}
      {showFilters && (
        <div
          style={{
            position: 'fixed',
            top: 0,
            right: 0,
            width: 300,
            height: '100vh',
            background: '#dcc889ff',
            boxShadow: '-2px 0 16px rgba(0,0,0,0.15)',
            zIndex: 1200,
            padding: '2rem 1.5rem',
            transition: 'right 0.3s',
            overflowY: 'auto',
          }}
        >
        </div>
      )}

      {/* Main Content */}
      {restaurants.map((restaurant) => (
        <div key={restaurant.id} style={{ display: 'flex', marginBottom: '2rem' }}>
          <section style={{ flex: 1 }}>
            <h1 style={{ marginBottom: 0 }}>{restaurant.name}</h1>
            <div style={{ color: '#666', marginBottom: 24 }}>{restaurant.location}</div>
            <h2 style={{ fontSize: '1.3rem', marginBottom: 16 }}>All Items</h2>
            <div
              style={{
                display: 'flex',
                gap: 32,
                flexWrap: 'wrap',
                justifyContent: 'center',
                alignItems: 'flex-start',
                width: '100%',
                margin: '0 auto',
                paddingBottom: 32
              }}
            >
              {restaurant.menu.map(item => (
                <div key={item.name} style={{
                  width: 320,
                  minHeight: 320,
                  background: '#fff',
                  borderRadius: 16,
                  boxShadow: '0 2px 16px rgba(0,0,0,0.10)',
                  padding: 20,
                  textAlign: 'center',
                  marginBottom: 32,
                  display: 'flex',
                  flexDirection: 'column',
                  justifyContent: 'space-between'
                }}>
                  <img src={item.img} alt={item.name} style={{ width: '100%', height: 160, objectFit: 'cover', borderRadius: 10 }} />
                  <div style={{ fontWeight: 700, marginTop: 12, fontSize: 18 }}>{item.name}</div>
                  <div style={{ color: '#666', fontSize: 15, marginBottom: 8 }}>{item.desc}</div>
                  <div style={{ marginBottom: 12 }}>
                    <span style={{ fontWeight: 700, fontSize: 17 }}>₹ {item.price}</span>
                    <span style={{ color: '#888', textDecoration: 'line-through', marginLeft: 10, fontSize: 14 }}>₹ {item.oldPrice}</span>
                  </div>
                  <button
                    style={{
                      background: '#dbc17cff',
                      color: '#fff',
                      border: 'none',
                      borderRadius: 8,
                      padding: '10px 28px',
                      fontWeight: 600,
                      cursor: 'pointer'
                    }}
                    onClick={() => addToCart({
                      id: getItemId(restaurant.id, item.name),
                      name: item.name,
                      price: item.price,
                      image: item.img,
                      restaurant: restaurant.name,
                      oldPrice: item.oldPrice
                    })}
                  >
                    Add item
                  </button>
                </div>
              ))}
            </div>
          </section>
        </div>
      ))}
    </div>
  );
}