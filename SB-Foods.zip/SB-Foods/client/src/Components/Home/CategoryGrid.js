import React from 'react';
import { categories } from '../../data/mockData';

const CategoryGrid = ({ onCategorySelect, selectedCategory }) => {
  return (
    <section className="category-section" id="categories">
      <div className="category-container">
        <h2 className="category-title">Browse by Category</h2>
        <p className="category-subtitle">Find exactly what you're craving</p>
        <div className="category-grid">
          {categories.map((category) => (
            <div
              key={category.id}
              className={`category-card ${selectedCategory === category.id ? 'active' : ''}`}
              onClick={() => onCategorySelect(
                selectedCategory === category.id ? null : category.id
              )}
            >
              <div className="category-image">
                {category.emoji}
              </div>
              <h3 className="category-name">{category.name}</h3>
              <p className="category-description">{category.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default CategoryGrid;