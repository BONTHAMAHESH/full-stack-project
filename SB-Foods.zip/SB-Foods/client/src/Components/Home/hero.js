import React from 'react';

const Hero = () => {
  return (
    <section className="hero">
      <div className="hero-content">
        <h1>Your Favorite Food Delivered Fresh</h1>
        <p>
          From midnight cravings to family dinners, we deliver delicious meals right to your door. 
          Perfect for students, professionals, and everyone in between.
        </p>
        <div className="hero-features">
          <div className="hero-feature">
            <span>⚡</span>
            <span>Fast Delivery</span>
          </div>
          <div className="hero-feature">
            <span>📱</span>
            <span>Track Your Order</span>
          </div>
          <div className="hero-feature">
            <span>⭐</span>
            <span>Top Rated</span>
          </div>
        </div>
        <a href="#categories" className="hero-cta">
          Order Now
        </a>
      </div>
    </section>
  );
};

export default Hero;