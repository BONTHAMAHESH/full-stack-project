import React from 'react';

const deals = [
  { title: '50% Off on First Order', desc: 'Use code FIRST50', img: '/images/deal1.jpg' },
  { title: 'Free Delivery', desc: 'On orders above ₹299', img: '/images/deal2.jpg' },
  { title: 'Combo Meals', desc: 'Save up to ₹100', img: '/images/deal3.jpg' },
];

export default function DealsSection() {
  return (
    <section className="deals-section">
      <h2 className="deals-title">Deals</h2>
      <div className="deals-grid">
        {deals.map(deal => (
          <div className="deals-card" key={deal.title}>
            <img src={deal.img} alt={deal.title} className="deals-image" />
            <div className="deals-info">
              <div className="deals-name">{deal.title}</div>
              <div className="deals-description">{deal.desc}</div>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}