import React from 'react';

const menuItems = [
  { name: 'Mc Maharaj', price: 175, img: '/images/burger.jpg', desc: 'Big size burger with chicken patty' },
  { name: 'French fries', price: 134, img: '/images/fries.jpg', desc: 'Long French fries made from potatoes' },
  { name: 'Cold Coffee', price: 201, img: '/images/coffee.jpg', desc: 'Tender coffee made from special beans' },
  { name: 'Chicken Pizza', price: 314, img: '/images/pizza.jpg', desc: 'Crispy pizza with tasty chicken' },
];

export default function MenuSection() {
  return (
    <section className="dish-section">
      <h2 className="dish-title">Menu</h2>
      <div className="dish-grid">
        {menuItems.map(item => (
          <div className="dish-card" key={item.name}>
            <img src={item.img} alt={item.name} className="dish-image" />
            <div className="dish-info">
              <div className="dish-name">{item.name}</div>
              <div className="dish-description">{item.desc}</div>
              <div className="dish-footer">
                <span className="dish-price">₹ {item.price}</span>
                <button className="add-to-cart">Add item</button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}