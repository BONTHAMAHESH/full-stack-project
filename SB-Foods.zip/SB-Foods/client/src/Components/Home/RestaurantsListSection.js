import React from 'react';

const restaurants = [
  { name: 'Andhra Spice', location: 'Madhapur', img: '/images/andhra-spice.jpg' },
  { name: 'McDonalds', location: 'Manikonda', img: '/images/mcdonalds.jpg' },
  { name: 'Paradise Grand', location: 'Hitech City', img: '/images/paradise.jpg' },
  { name: 'Minerva Grand', location: 'Kukatpally', img: '/images/minerva.jpg' },
];

export default function RestaurantsListSection() {
  return (
    <section className="category-section">
      <h2 className="category-title">Restaurants</h2>
      <div className="category-grid">
        {restaurants.map(r => (
          <div className="category-card" key={r.name}>
            <img src={r.img} alt={r.name} className="category-image" />
            <div className="category-name">{r.name}</div>
            <div className="category-description">{r.location}</div>
          </div>
        ))}
      </div>
    </section>
  );
}