import React, { useState } from 'react';
import { X, ShoppingBag } from 'lucide-react';
import { useCart } from '../../hooks/useCart';
import CheckoutModal from './CheckoutModal';

const CartDrawer = ({ isOpen, onClose }) => {
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const { items, removeItem, totalPrice } = useCart();

  if (!isOpen) return null;

  const deliveryFee = 50;
  const discount = 66;
  const finalTotal = totalPrice - discount + deliveryFee;

  const handleCheckout = () => setIsCheckoutOpen(true);

  return (
    <>
      <div className="cart-drawer-backdrop" onClick={onClose} />
      <div className="cart-drawer">
        <div className="cart-drawer-header">
          <span className="cart-drawer-title">Your Cart</span>
          <button onClick={onClose} className="cart-drawer-close" aria-label="Close cart">
            <X className="h-6 w-6" />
          </button>
        </div>
        <div className="cart-items-list">
          {items.length === 0 ? (
            <div className="empty-cart">
              <ShoppingBag className="h-16 w-16 mb-4" />
              <p className="text-lg font-medium">Your cart is empty</p>
              <p className="text-sm text-center">Add some delicious items to get started!</p>
            </div>
          ) : (
            items.map(item => (
              <div key={item.id} className="cart-item">
                <img src={item.image || '/default-food.png'} alt={item.name} className="cart-item-img" />
                <div className="cart-item-info">
                  <span className="cart-item-title">{item.name}</span>
                  <span className="cart-item-restaurant">{item.restaurant}</span>
                  <span className="cart-item-price">
                    Price: ₹ {item.price}
                    {item.oldPrice && (
                      <span style={{ textDecoration: 'line-through', color: '#aaa', marginLeft: 8 }}>₹{item.oldPrice}</span>
                    )}
                  </span>
                  <span>Quantity: {item.quantity}</span>
                </div>
                <button className="cart-item-remove" onClick={() => removeItem(item.id)}>Remove</button>
              </div>
            ))
          )}
        </div>
        {items.length > 0 && (
          <div className="cart-drawer-summary">
            <div className="cart-summary-row">
              <span>Total MRP:</span>
              <span>₹ {totalPrice}</span>
            </div>
            <div className="cart-summary-row">
              <span>Discount on MRP:</span>
              <span style={{ color: '#16a34a' }}>- ₹ {discount}</span>
            </div>
            <div className="cart-summary-row">
              <span>Delivery Charges:</span>
              <span style={{ color: '#ef4444' }}>+ ₹ {deliveryFee}</span>
            </div>
            <div className="cart-summary-row total">
              <span>Final Price:</span>
              <span>₹ {finalTotal}</span>
            </div>
            <button className="cart-checkout-btn" onClick={handleCheckout}>Place order</button>
          </div>
        )}
      </div>
      {isCheckoutOpen && (
        <CheckoutModal
          isOpen={isCheckoutOpen}
          onClose={() => setIsCheckoutOpen(false)}
          onOrderComplete={() => {
            setIsCheckoutOpen(false);
            onClose();
          }}
        />
      )}
    </>
  );
};

export default CartDrawer;