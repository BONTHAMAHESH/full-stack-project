// Dish object shape for reference:
// {
//   id: string,
//   name: string,
//   description: string,
//   price: number,
//   image: string,
//   restaurant: string,
//   category: string,
//   rating: number,
//   isPopular: boolean,
//   preparationTime: string
// }
import MaharajaImg from './images/maharaja.jpg';
import FriesImg from './images/pizza.jpg';
import CoffeeImg from './images/coffee.jpg';
import PizzaImg from './images/pizza.jpg';
import ChickenBiryaniImg from './images/chickenbiryani.jpg';
import MasaladosaImg from './images/masaladosa.jpg';
import NoodlesImg from './images/chickennoodles.jpg';
import PizzamImg from './images/pizzam.jpg';


export const mockDishes = [
  {
    id: '1',
    name: 'Mc Maharaj',
    description: 'Big size burger with chicken, cheese, lettuce and special sauce',
    price: 175,
    image: MaharajaImg,
    restaurant: 'Mc donalds',
    category: 'burger',
    rating: 4.5,
    isPopular: true,
    preparationTime: '15-20 mins'
  },
  {
    id: '2',
    name: 'French Fries',
    description: 'Long French fries made from fresh potatoes, crispy and golden',
    price: 134,
    image: FriesImg,
    restaurant: 'Mc donalds',
    category: 'sides',
    rating: 4.2,
    isPopular: true,
    preparationTime: '5-10 mins'
  },
  {
    id: '3',
    name: 'Cold Coffee',
    description: 'Tender coffee made from premium beans with ice and cream',
    price: 201,
    image: CoffeeImg,
    restaurant: 'Mc donalds',
    category: 'beverages',
    rating: 4.3,
    isPopular: false,
    preparationTime: '5 mins'
  },
  {
    id: '4',
    name: 'Chicken Pizza',
    description: 'Crispy pizza with tasty chicken, cheese and fresh vegetables',
    price: 314,
    image: PizzaImg,
    restaurant: 'Paradise Grand',
    category: 'pizza',
    rating: 4.7,
    isPopular: true,
    preparationTime: '20-25 mins'
  },
  {
    id: '5',
    name: 'Chicken Biryani',
    description: 'Aromatic basmati rice with tender chicken and traditional spices',
    price: 299,
    image: ChickenBiryaniImg,
    restaurant: 'Andhra Spice',
    category: 'biryani',
    rating: 4.8,
    isPopular: true,
    preparationTime: '25-30 mins'
  },
  {
    id: '6',
    name: 'Masala Dosa',
    description: 'Crispy South Indian crepe with spiced potato filling',
    price: 149,
    image: MasaladosaImg,
    restaurant: 'Andhra Spice',
    category: 'breakfast',
    rating: 4.4,
    isPopular: false,
    preparationTime: '15-20 mins'
  },
  {
    id: '7',
    name: 'Chicken Noodles',
    description: 'Stir-fried noodles with chicken and fresh vegetables',
    price: 189,
    image: NoodlesImg,
    restaurant: 'Minarva Grand',
    category: 'noodles',
    rating: 4.3,
    isPopular: true,
    preparationTime: '15-20 mins'
  },
  {
    id: '8',
    name: 'Margherita Pizza',
    description: 'Classic Italian pizza with fresh mozzarella and basil',
    price: 249,
    image: PizzamImg,
    restaurant: 'Paradise Grand',
    category: 'pizza',
    rating: 4.6,
    isPopular: true,
    preparationTime: '18-22 mins'
  }
];

export const categories = [
  { id: 'breakfast', name: 'Breakfast', emoji: '🍳' },
  { id: 'biryani', name: 'Biryani', emoji: '🍛' },
  { id: 'pizza', name: 'Pizza', emoji: '🍕' },
  { id: 'noodles', name: 'Noodles', emoji: '🍜'},
  { id: 'burger', name: 'Burger', emoji: '🍔' },
  { id: 'beverages', name: 'Beverages', emoji: '🥤'}
];

export const restaurants = [
  {
    id: '1',
    name: 'Andhra Spice',
    location: 'Madhapur, Hyderabad',
    image: 'https://images.pexels.com/photos/260922/pexels-photo-260922.jpeg?auto=compress&cs=tinysrgb&w=400',
    rating: 4.5,
    deliveryTime: '25-30 mins'
  },
  {
    id: '2',
    name: 'Mc donalds',
    location: 'Manikonda, Hyderabad',
    image: 'https://images.pexels.com/photos/1552635/pexels-photo-1552635.jpeg?auto=compress&cs=tinysrgb&w=400',
    rating: 4.2,
    deliveryTime: '15-20 mins'
  },
  {
    id: '3',
    name: 'Paradise Grand',
    location: 'Banjara Hills, Hyderabad',
    image: 'https://images.pexels.com/photos/67468/pexels-photo-67468.jpeg?auto=compress&cs=tinysrgb&w=400',
    rating: 4.7,
    deliveryTime: '20-25 mins'
  },
  {
    id: '4',
    name: 'Minarva Grand',
    location: 'Kukatpally, Hyderabad',
    image: 'https://images.pexels.com/photos/941861/pexels-photo-941861.jpeg?auto=compress&cs=tinysrgb&w=400',
    rating: 4.4,
    deliveryTime: '18-25 mins'
  }
];