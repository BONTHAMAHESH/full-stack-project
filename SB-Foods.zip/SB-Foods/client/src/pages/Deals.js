import React, { useEffect, useState } from 'react';
import axios from 'axios';

function Deals() {
  const [deals, setDeals] = useState([]);
  useEffect(() => {
    axios.get('http://localhost:5000/api/deals')
      .then(res => setDeals(res.data));
  }, []);
  return (
    <div className="deals-page-container">
      <h2>Deals</h2>
      <ul className="deals-list">
        {deals.map(deal => (
          <li className="deal-card" key={deal.id}>
            {deal.title} (Code: {deal.code})
          </li>
        ))}
      </ul>
    </div>
  );
}

export default Deals;