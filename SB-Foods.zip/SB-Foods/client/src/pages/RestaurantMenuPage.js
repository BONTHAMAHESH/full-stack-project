import React, { useState } from 'react';
import { useParams } from 'react-router-dom';
import Sidebar from '../Components/SideBar';
import MenuItemCard from '../Components/RestaurantMenu';

const RestaurantMenuPage = () => {
  const { id } = useParams();
  const [selectedCategory, setSelectedCategory] = useState('All Items');
  const [sortBy, setSortBy] = useState('Popularity');

  const menuItems = [
    {
      id: 1,
      name: 'Mc Maharaja',
      description: 'Big size burger with chicken, lettuce, tomato, onion and mayo',
      price: 175299,
      image: 'https://images.pexels.com/photos/1556698/pexels-photo-1556698.jpeg?auto=compress&cs=tinysrgb&w=400',
      category: 'Burger'
    },
    {
      id: 2,
      name: 'French fries',
      description: 'Long French fries made fresh with salt and pepper',
      price: 134149,
      image: 'https://images.pexels.com/photos/1583884/pexels-photo-1583884.jpeg?auto=compress&cs=tinysrgb&w=400',
      category: 'Sides'
    },
    {
      id: 3,
      name: 'Cold Coffee',
      description: 'Tender coffee made from premium beans with milk and sugar',
      price: 201249,
      image: 'https://images.pexels.com/photos/302899/pexels-photo-302899.jpeg?auto=compress&cs=tinysrgb&w=400',
      category: 'Beverages'
    },
    {
      id: 4,
      name: 'Chicken Pizza',
      description: 'Crispy pizza with tasty chicken, cheese, onions and peppers',
      price: 314349,
      image: 'https://images.pexels.com/photos/315755/pexels-photo-315755.jpeg?auto=compress&cs=tinysrgb&w=400',
      category: 'Pizza'
    }
  ];

  const filteredItems = selectedCategory === 'All Items' 
    ? menuItems 
    : menuItems.filter(item => item.category === selectedCategory);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="flex gap-8">
        <Sidebar 
          selectedCategory={selectedCategory}
          setSelectedCategory={setSelectedCategory}
          sortBy={sortBy}
          setSortBy={setSortBy}
        />
        
        <div className="flex-1">
          <div className="mb-6">
            <h1 className="text-3xl font-bold text-gray-900">Mc donalds</h1>
            <p className="text-gray-600">Manikonda, Hyderabad</p>
          </div>
          
          <div className="mb-6">
            <h2 className="text-xl font-semibold text-gray-900 mb-4">{selectedCategory}</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {filteredItems.map((item) => (
                <MenuItemCard key={item.id} item={item} />
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default RestaurantMenuPage;