import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';

const Register = () => {
  const { register } = useAuth();
  const [form, setForm] = useState({ name: '', email: '', password: '' });

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    await register(form);
  };

  return (
    <form onSubmit={handleSubmit} className="p-8 max-w-md mx-auto">
      <input name="name" value={form.name} onChange={handleChange} placeholder="Name" className="w-full p-2 border mb-4" />
      <input name="email" value={form.email} onChange={handleChange} placeholder="Email" className="w-full p-2 border mb-4" />
      <input type="password" name="password" value={form.password} onChange={handleChange} placeholder="Password" className="w-full p-2 border mb-4" />
      <button type="submit" className="bg-orange-500 text-white px-4 py-2">Register</button>
    </form>
  );
};

export default Register;