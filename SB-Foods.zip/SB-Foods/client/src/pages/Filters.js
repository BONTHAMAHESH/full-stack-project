import React, { useEffect, useState } from 'react';
import axios from 'axios';

function Filters() {
  const [filters, setFilters] = useState([]);

  useEffect(() => {
    axios.get('http://localhost:5000/api/filters')
      .then(res => setFilters(res.data));
  }, []);

  return (
    <div className="filters-page-container">
      <h2>Filters</h2>
      <ul className="filters-list">
        {filters.map(filter => (
          <li className="filter-item" key={filter.id}>
            <span className="filter-name">{filter.name}:</span>
            <span className="filter-options">
              {Array.isArray(filter.options) ? filter.options.join(', ') : ''}
            </span>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default Filters;