import React from 'react';

function UserDashboard() {
  return (
    <div>
      {/* Dashboard content only, no UserProfile or user info card here */}
      <h2>Orders</h2>
      {/* ...orders, stats, etc... */}
    </div>
  );
}

export default UserDashboard;