import React, { useEffect, useState } from 'react';
import axios from 'axios';

function Support() {
  const [info, setInfo] = useState(null);

  useEffect(() => {
    axios.get('http://localhost:5000/api/support')
      .then(res => setInfo(res.data));
  }, []);

  if (!info) return <div>Loading...</div>;

  return (
    <div className="support-page-container">
      <h2>Support</h2>
      <div className="support-info">
        For help or questions, reach out to our support team.
      </div>
      <div className="support-contact">
        <p>📧 support@sbfoods.com</p>
        <p>📞 (555) 123-4567</p>
        <p>📍 123 Food Street, City</p>
      </div>
    </div>
  );
}

export default Support;