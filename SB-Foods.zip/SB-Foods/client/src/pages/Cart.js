import React from 'react';
import { useCart } from '../hooks/useCart';

function Cart() {
  const { items, removeFromCart } = useCart();

  return (
    <div className="cart-page-container">
      <h2>Your Cart</h2>
      {items.length === 0 ? (
        <p>Your cart is empty.</p>
      ) : (
        <ul>
          {items.map(item => (
            <li key={item.id}>
              {item.name} - Qty: {item.quantity} - ₹{item.price * item.quantity}
              <button
                style={{ marginLeft: 12 }}
                onClick={() => removeFromCart(item.id)}
              >
                Remove
              </button>
            </li>
          ))}
        </ul>
      )}
      <div className="cart-summary">
        Total: ₹{items.reduce((sum, item) => sum + item.price * item.quantity, 0)}
      </div>
    </div>
  );
}

export default Cart;
