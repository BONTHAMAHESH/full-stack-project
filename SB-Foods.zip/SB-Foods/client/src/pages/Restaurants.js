import React, { useEffect, useState } from 'react';
import axios from 'axios';
import McDonaldsImg from '../images/mcdonalds.jpg';
import ParadiseImg from '../images/paradise.jpg';
import AndhraSpiceImg from '../images/andhraspice.jpg';
import KritungaImg from '../images/kritunga.jpg';
import MinervaGrandImg from '../images/minervagrand.jpg';
import ExoticaImg from '../images/exotica.jpg';

const restaurantImages = {
  "Mc donalds": McDonaldsImg,
  "Andhra Spice": ParadiseImg,
  "Paradise Grand": AndhraSpiceImg,
  "Minerva Grand": MinervaGrandImg,
  "Kritunga": KritungaImg,
  "Exotica": ExoticaImg
};

const restaurantDescriptions = {
  "Mc donalds": "Classic fast food chain famous for burgers and fries.",
  "Andhra Spice": "Authentic Andhra cuisine with spicy flavors.",
  "Paradise Grand": "Legendary biryani and North Indian dishes.",
  "Minerva Grand": "South Indian specialties and family dining.",
  "Kritunga": "Known for spicy non-veg Andhra delicacies.",
  "Exotica": "Rooftop restaurant with multi-cuisine menu."
};

function RestaurantsPage() {
  const [restaurants, setRestaurants] = useState([]);

  useEffect(() => {
    axios.get('http://localhost:5000/api/restaurants')
      .then(res => setRestaurants(res.data));
  }, []);

  return (
    <div className="restaurants-page-container">
      <h2>Restaurants</h2>
      <div className="restaurants-grid">
        {restaurants.map(r => (
          <div className="restaurant-card" key={r.id}>
            <img
              src={restaurantImages[r.name] || "https://images.unsplash.com/photo-1504674900247-0877df9cc836?auto=format&fit=crop&w=400&q=80"}
              alt={r.name}
              className="restaurant-img"
            />
            <div className="restaurant-info">
              <h3>{r.name}</h3>
              <p className="restaurant-location">{r.location}</p>
              <p className="restaurant-desc">{restaurantDescriptions[r.name] || "Delicious food and great ambience."}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default RestaurantsPage;