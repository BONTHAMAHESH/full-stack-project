import React, { useEffect, useState } from 'react';
import axios from 'axios';
import McmaharajImg from '../images/maharaja.jpg';
import FrenchfriesImg from '../images/fries.jpg';
import ColdcoffeeImg from '../images/coffee.jpg';
import ChickenpizzaImg from '../images/pizza.jpg';
import ChickenbiryaniImg from '../images/chickenbiryani.jpg';

const itemImages = {
  "Mc Maharaj": McmaharajImg,
  "French Fries": FrenchfriesImg,
  "Cold Coffee": ColdcoffeeImg,
  "Chicken Pizza": ChickenpizzaImg,
  "Chicken Biryani": ChickenbiryaniImg
};

const itemDescriptions = {
  "Mc Maharaj": "Juicy burger with signature sauce and fresh veggies.",
  "French Fries": "Crispy golden fries, perfect with any meal.",
  "Cold Coffee": "Chilled coffee blended with ice and cream.",
  "Chicken Pizza": "Loaded with chicken, cheese, and spicy toppings.",
  "Chicken Biryani": "Aromatic rice with tender chicken and spices."
};

function Menu() {
  const [menu, setMenu] = useState([]);

  useEffect(() => {
    axios.get('http://localhost:5000/api/menu')
      .then(res => setMenu(res.data));
  }, []);

  return (
    <div className="menu-page-container">
      <h2>Menu</h2>
      <div className="menu-grid">
        {menu.map(item => (
          <div className="menu-card" key={item.id}>
            <img
              src={itemImages[item.name] || "https://images.unsplash.com/photo-1504674900247-0877df9cc836?auto=format&fit=crop&w=400&q=80"}
              alt={item.name}
              className="menu-img"
            />
            <div className="menu-info">
              <h3>{item.name}</h3>
              <p className="menu-desc">{itemDescriptions[item.name] || "Tasty and fresh!"}</p>
              <div className="menu-price">₹{item.price}</div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default Menu;