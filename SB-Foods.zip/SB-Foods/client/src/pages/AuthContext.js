// src/pages/AuthContext.js

import React, { createContext, useContext, useState } from 'react';

const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null); // or pull from localStorage

  const login = (userData) => {
    setUser(userData);
  };

  const signup = (name, email, password) => {
    // Dummy signup: just set user
    setUser({ name, email });
  };

  const logout = () => {
    setUser(null);
  };

  return (
    <AuthContext.Provider value={{ user, login, logout, signup }}>
      {children}
    </AuthContext.Provider>
  );
};

// ✅ THIS MUST BE PRESENT
export const useAuth = () => {
  return useContext(AuthContext);
};
