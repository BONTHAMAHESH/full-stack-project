// Dish object shape for reference:
// {
//   id: string,
//   name: string,
//   description: string,
//   price: number,
//   image: string,
//   category: string,
//   rating: number,
//   reviewCount: number,
//   cookTime: string,
//   isVegetarian?: boolean,
//   isSpicy?: boolean,
//   isPopular?: boolean,
//   restaurant: string,
//   ingredients: string[],
//   nutritionInfo?: {
//     calories: number,
//     protein: number,
//     carbs: number,
//     fat: number
//   }
// }

// CartItem object shape for reference:
// {
//   dish: Dish,
//   quantity: number,
//   customizations?: string[]
// }

// User object shape for reference:
// {
//   id: string,
//   name: string,
//   email: string,
//   phone: string,
//   addresses: Address[],
//   favoriteRestaurants: string[],
//   orderHistory: Order[]
// }

// Address object shape for reference:
// {
//   id: string,
//   label: string,
//   street: string,
//   city: string,
//   state: string,
//   zipCode: string,
//   isDefault: boolean
// }

// Order object shape for reference:
// {
//   id: string,
//   items: CartItem[],
//   total: number,
//   status: 'pending' | 'confirmed' | 'preparing' | 'out-for-delivery' | 'delivered' | 'cancelled',
//   deliveryAddress: Address,
//   paymentMethod: string,
//   orderTime: string,
//   estimatedDeliveryTime: string,
//   restaurant: string
// }

// Restaurant object shape for reference:
// {
//   id: string,
//   name: string,
//   image: string,
//   rating: number,
//   deliveryTime: string,
//   deliveryFee: number,
//   minimumOrder: number,
//   cuisine: string[],
//   isOpen: boolean,
//   openUntil: string
// }